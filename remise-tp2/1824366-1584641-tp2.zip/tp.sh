#!/bin/sh
./executable.py "$@"
